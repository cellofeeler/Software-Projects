import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     * Test constructor.
     */
    @Test
    public final void testConstructor() {
        Map<String, String> map = this.constructorTest();
        Map<String, String> mapExpected = this.constructorRef();

        assertEquals(mapExpected, map);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void addTestOne() {
        Map<String, String> map = this.createFromArgsTest("play", "time");
        Map<String, String> mapExpected = this.createFromArgsRef("play", "time",
                "money", "change");

        map.add("money", "change");

        boolean result = map.hasKey("money") && map.hasValue("change");

        assertTrue(result);
        assertEquals(mapExpected, map);
    }

    /**
     * Test case for add.
     */
    @Test
    public final void addTestTwo() {
        Map<String, String> map = this.createFromArgsTest("make", "bake",
                "change", "craze");
        Map<String, String> mapExpected = this.createFromArgsRef("make", "bake",
                "change", "craze", "fry", "dry");

        map.add("fry", "dry");

        boolean result = map.hasKey("fry") && map.hasValue("dry");

        assertTrue(result);
        assertEquals(mapExpected, map);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void removeTestOne() {
        Map<String, String> map = this.createFromArgsTest("make", "bake");
        Map<String, String> mapExpected = this.createFromArgsRef();

        map.remove("make");

        boolean result = map.hasKey("make") && map.hasValue("bake");

        assertEquals(result, false);
        assertEquals(mapExpected, map);
    }

    /**
     * Test case for remove.
     */
    @Test
    public final void removeTestTwo() {
        Map<String, String> map = this.createFromArgsTest("make", "bake",
                "craze", "haze", "fry", "dry");
        Map<String, String> mapExpected = this.createFromArgsRef("make", "bake",
                "fry", "dry");

        map.remove("craze");

        boolean result = map.hasKey("craze") && map.hasValue("haze");

        assertEquals(result, false);
        assertEquals(mapExpected, map);
    }

    /**
     * Test case for removeAny.
     */
    @Test
    public final void removeAnyTestOne() {
        /**
         * Setup expected and actual objects
         */
        Map<String, String> map = this.createFromArgsTest("play", "time",
                "money", "change");
        Map<String, String> mapExpected = this.createFromArgsRef("play", "time",
                "money", "change");

        /**
         * Call the method on the actual object
         */
        Pair<String, String> p = map.removeAny();

        /**
         * Evaluate the values given from the call
         */
        assertEquals(mapExpected.hasKey(p.key()), true);
        assertEquals(mapExpected.hasValue(p.value()), true);

        Pair<String, String> pair = mapExpected.remove(p.key());

        assertEquals(p, pair);
        assertEquals(mapExpected, map);

    }

    /**
     * Test value on a map of 1.
     */
    @Test
    public final void valueTestMapOne() {
        Map<String, String> map = this.createFromArgsTest("red", "apple");
        Map<String, String> mapExpected = this.createFromArgsRef("red",
                "apple");

        String value = map.value("red");

        assertEquals("apple", value);
        assertEquals(mapExpected, map);

    }

    /**
     * Test value on a map of 3.
     */
    @Test
    public final void valueTestMapThree() {
        Map<String, String> map = this.createFromArgsTest("red", "apple",
                "green", "kiwi", "purple", "grapes");
        Map<String, String> mapExpected = this.createFromArgsRef("red", "apple",
                "green", "kiwi", "purple", "grapes");

        String value = map.value("purple");

        assertEquals("grapes", value);
        assertEquals(mapExpected, map);
    }

    /**
     * Test value on a map of 6.
     */
    @Test
    public final void valueTestMapSix() {
        Map<String, String> map = this.createFromArgsTest("red", "apple",
                "green", "kiwi", "purple", "grapes", "clear", "water", "blue",
                "blueberry", "yellow", "banana");
        Map<String, String> mapExpected = this.createFromArgsRef("red", "apple",
                "green", "kiwi", "purple", "grapes", "clear", "water", "blue",
                "blueberry", "yellow", "banana");

        String value = map.value("blue");

        assertEquals("blueberry", value);
        assertEquals(mapExpected, map);
    }

    /**
     * Test has key on a map of 1.
     */
    @Test
    public final void hasKeyTestMapOne() {
        Map<String, String> map = this.createFromArgsTest("red", "apple");
        Map<String, String> mapExpected = this.createFromArgsRef("red",
                "apple");

        boolean bool = map.hasKey("red");

        assertEquals(true, bool);
        assertEquals(mapExpected, map);

    }

    /**
     * Test has key on a map of 3.
     */
    @Test
    public final void hasKeyTestMapThree() {
        Map<String, String> map = this.createFromArgsTest("red", "apple",
                "green", "kiwi", "purple", "grapes");
        Map<String, String> mapExpected = this.createFromArgsRef("red", "apple",
                "green", "kiwi", "purple", "grapes");

        boolean bool = map.hasKey("green");

        assertEquals(true, bool);
        assertEquals(mapExpected, map);

    }

    /**
     * Test has key on a map of 6.
     */
    @Test
    public final void hasKeyTestMapSix() {
        Map<String, String> map = this.createFromArgsTest("red", "apple",
                "green", "kiwi", "purple", "grapes", "clear", "water", "blue",
                "blueberry", "yellow", "banana");
        Map<String, String> mapExpected = this.createFromArgsRef("red", "apple",
                "green", "kiwi", "purple", "grapes", "clear", "water", "blue",
                "blueberry", "yellow", "banana");

        boolean bool = map.hasKey("clear");

        assertEquals(true, bool);
        assertEquals(mapExpected, map);

    }

    /**
     * Test size on an empty map.
     */
    @Test
    public final void sizeTestEmptyMap() {
        Map<String, String> map = this.createFromArgsTest();

        int i = map.size();

        assertEquals(0, i);
    }

    /**
     * Test size on non-empty map.
     */
    @Test
    public final void sizeTestNonEmptyMap() {
        Map<String, String> map = this.createFromArgsTest("red", "apples",
                "orange", "oranges", "purple", "grapes", "green", "kiwis");

        int i = map.size();

        assertEquals(4, i);
    }

}
