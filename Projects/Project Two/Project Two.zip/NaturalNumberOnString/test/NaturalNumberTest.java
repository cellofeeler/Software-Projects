import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Chloe Feller and Krish Patel
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /**
     * No-argument constructor.
     */
    @Test
    public void testNoArgumentConstructor() {

        NaturalNumber q = this.constructorTest();
        NaturalNumber qExpected = this.constructorRef();

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code int}.
     */
    @Test
    public void testNoArgumentConstructorInt() {
        NaturalNumber q = this.constructorRef(0);
        NaturalNumber qExpected = this.constructorTest(0);

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code int}.
     */
    @Test
    public void testNoArgumentConstructorIntWithOneDigit() {
        NaturalNumber q = this.constructorRef(5);
        NaturalNumber qExpected = this.constructorTest(5);

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code int}.
     */
    @Test
    public void testNoArgumentConstructorIntWithTwoDigits() {
        NaturalNumber q = this.constructorRef(42);
        NaturalNumber qExpected = this.constructorTest(42);

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code int}.
     */
    @Test
    public void testNoArgumentConstructorIntWithMaxDigits() {
        NaturalNumber q = this.constructorRef(Integer.MAX_VALUE);
        NaturalNumber qExpected = this.constructorTest(Integer.MAX_VALUE);

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code String}.
     */
    @Test
    public void testNoArgumentConstructorStringZeroString() {
        NaturalNumber q = this.constructorRef("0");
        NaturalNumber qExpected = this.constructorTest("0");

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code String}.
     */
    @Test
    public void testNoArgumentConstructorWithOneDigitString() {
        NaturalNumber q = this.constructorRef("4");
        NaturalNumber qExpected = this.constructorTest("4");

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code String}.
     */
    @Test
    public void testNoArgumentConstructorWithTwoDigitsString() {
        NaturalNumber q = this.constructorRef("98");
        NaturalNumber qExpected = this.constructorTest("98");

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code NaturalNumber}.
     */
    @Test
    public void testNoArgumentConstructorNN() {
        NaturalNumber q = this.constructorRef(this.constructorRef("0"));
        NaturalNumber qExpected = this
                .constructorTest(this.constructorTest("0"));

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code NaturalNumber}.
     */
    @Test
    public void testNoArgumentConstructorNNWithOneDigit() {
        NaturalNumber q = this.constructorRef(this.constructorRef("7"));
        NaturalNumber qExpected = this
                .constructorTest(this.constructorTest("7"));

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code NaturalNumber}.
     */
    @Test
    public void testNoArgumentConstructorNNWithTwoDogits() {
        NaturalNumber q = this.constructorRef(this.constructorRef("96"));
        NaturalNumber qExpected = this
                .constructorTest(this.constructorTest("96"));

        assertEquals(qExpected, q);
    }

    /**
     * Constructor from {@code NaturalNumber}.
     */
    @Test
    public void testNoArgumentConstructorNNWithALotOfNumbers() {
        NaturalNumber q = this
                .constructorRef(this.constructorRef("98765432123456789"));
        NaturalNumber qExpected = this
                .constructorTest(this.constructorTest("98765432123456789"));

        assertEquals(qExpected, q);
    }

    // TODO - multipleBy10 Test Cases

    /**
     * Basic case of k = 0 and this = 0.
     */
    @Test
    public void testMultiplyBy10WithZero() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(0);
        NaturalNumber qExpected = this.constructorRef(0);

        /**
         * Call Method.
         */
        q.multiplyBy10(0);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Similar to above test case, but with k = 5.
     */
    @Test
    public void testMultiplyBy10WithZeroWithAddition() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(0);
        NaturalNumber qExpected = this.constructorRef(0);

        /**
         * Call Method.
         */
        q.multiplyBy10(5);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with one digit.
     */
    @Test
    public void testMultiplyBy10WithOneDigit() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(3);
        NaturalNumber qExpected = this.constructorRef(30);

        /**
         * Call Method.
         */
        q.multiplyBy10(0);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with one digit with addition of 4.
     */
    @Test
    public void testMultiplyBy10WithOneDigitWithAddition() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(3);
        NaturalNumber qExpected = this.constructorRef(34);

        /**
         * Call Method.
         */
        q.multiplyBy10(4);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with two digits.
     */
    @Test
    public void testMultiplyBy10WithTwoDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(38);
        NaturalNumber qExpected = this.constructorRef(380);

        /**
         * Call Method.
         */
        q.multiplyBy10(0);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with two digits with addition of 9.
     */
    @Test
    public void testMultiplyBy10WithTwoDigitsWithAddition() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(38);
        NaturalNumber qExpected = this.constructorRef(389);

        /**
         * Call Method.
         */
        q.multiplyBy10(9);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with multiple digits.
     */
    @Test
    public void testMultiplyBy10WithMultipleDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(98365492);
        NaturalNumber qExpected = this.constructorRef(983654920);

        /**
         * Call Method.
         */
        q.multiplyBy10(0);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    /**
     * Multiply with multiple digits with addition of 1.
     */
    @Test
    public void testMultiplyBy10WithMultipleDigitsWithAddition() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(98365492);
        NaturalNumber qExpected = this.constructorRef(983654921);

        /**
         * Call Method.
         */
        q.multiplyBy10(1);

        /**
         * Assert Values.
         */
        assertEquals(qExpected, q);
    }

    // TODO - divideBy10 Test Cases

    /**
     * test q value as zero.
     */
    @Test
    public void testDivideBy10WithZero() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(0);
        NaturalNumber qExpected = this.constructorRef(0);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(0, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with a Remainder Option while having q have double digits.
     */
    @Test
    public void testDivideBy10WithARemainderWithDoubleDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(13);
        NaturalNumber qExpected = this.constructorRef(1);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(3, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with no Remainder Option while having q have double digits.
     */
    @Test
    public void testDivideBy10WithNoRemainderWithDoubleDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(30);
        NaturalNumber qExpected = this.constructorRef(3);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(0, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with a Remainder Option while having q have triple digits.
     */
    @Test
    public void testDivideBy10WithARemainderWithTripleDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(235);
        NaturalNumber qExpected = this.constructorRef(23);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(5, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with no Remainder Option while having q have triple digits.
     */
    @Test
    public void testDivideBy10WithNoRemainderWithTripleDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(720);
        NaturalNumber qExpected = this.constructorRef(72);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(0, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with a Remainder Option while having q have an absurd amount of
     * digits.
     */
    @Test
    public void testDivideBy10WithARemainderWithAbsurdDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(987654329);
        NaturalNumber qExpected = this.constructorRef(98765432);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(9, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * test with no Remainder Option while having q have an absurd amount of
     * digits.
     */
    @Test
    public void testDivideBy10WithNoRemainderWithAbsurdDigits() {

        /**
         * Variables.
         */
        NaturalNumber q = this.constructorTest(987654320);
        NaturalNumber qExpected = this.constructorRef(98765432);

        /**
         * Call Method.
         */
        int remainder = q.divideBy10();

        /**
         * Assert Values.
         */
        assertEquals(0, remainder);
        assertEquals(qExpected, q);
    }

    /**
     * Test isZero with 0.
     */
    @Test
    public final void testIsZeroWithZero() {
        /**
         * Create variables.
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        /**
         * Call method.
         */
        boolean zero = n.isZero();

        /**
         * Evaluate test.
         */
        assertEquals(zero, true);
        assertEquals(n, nExpected);

    }

    /**
     * Test isZero with a number that is not zero.
     */
    @Test
    public final void testIsZeroWithoutZero() {
        /**
         * Create variables.
         */
        NaturalNumber n = this.constructorTest(347);
        NaturalNumber nExpected = this.constructorRef(347);

        /**
         * Call method.
         */
        boolean zero = n.isZero();

        /**
         * Evaluate test.
         */
        assertEquals(zero, false);
        assertEquals(n, nExpected);

    }

    /**
     * Test isZero with a null NaturalNumber.
     */
    @Test
    public final void testIsZeroWithNull() {
        /**
         * Create variables.
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();

        /**
         * Call method.
         */
        boolean zero = n.isZero();

        /**
         * Evaluate test.
         */
        assertEquals(zero, true);
        assertEquals(n, nExpected);

    }
}
