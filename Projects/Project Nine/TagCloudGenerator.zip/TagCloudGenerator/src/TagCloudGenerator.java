import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;
import components.utilities.Reporter;

/**
 * Creates a tag cloud from a given file input text.
 *
 * @author Chloe Feller
 * @author Krish Patel
 *
 */
public final class TagCloudGenerator {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private TagCloudGenerator() {
    }

    /**
     * This is a numerical ordering system which orders the largest numbers over
     * the smaller numbers.
     */
    private static class Sort implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> one,
                Map.Pair<String, Integer> two) {
            int compared = 0;
            if (one.value().equals(two.value())) {
                compared = one.key().compareToIgnoreCase(two.key());
            } else {
                compared = two.value().compareTo(one.value());
            }
            return compared;
        }

    }

    /**
     * This is an alphabetical ordering system which orders words starting from
     * a all the way to z.
     */
    private static class SortTwo
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> one,
                Map.Pair<String, Integer> two) {
            return one.key().compareToIgnoreCase(two.key());
        }
    }

    /**
     * Reads words from the input file and adds them to a {@code Map}. Words are
     * not alphabetized yet.
     *
     * @param words
     *            the {@code Map} of words
     * @param file
     *            file input by user
     *
     * @requires file.isOpen
     * @requires words != null
     * @replaces words
     *
     */
    private static void readFile(Map<String, Integer> words,
            SimpleReader file) {
        assert file.isOpen() : "Violation of: file is open";
        assert words != null : "Violation of: words is not null";

        String separator = " \t,.-;'/\"@#$%&()*`";
        Set<Character> charSet = new Set1L<Character>();

        generateElements(separator, charSet);

        /*
         * Read through the file until all lines are read, while adding words to
         * the Map
         */
        while (!file.atEOS()) {
            String line = file.nextLine();
            int i = 0;

            while (i < line.length()) {
                String text = nextWordOrSeparator(line, i, charSet);
                if (!charSet.contains(text.charAt(0))) {
                    /*
                     * Sees if words contains the word. If it does not, the word
                     * is added. If it does, the number of times it has appeared
                     * is increased.
                     */
                    if (words.hasKey(text)) {
                        int numberAppear = words.value(text);
                        numberAppear++;
                        words.replaceValue(text, numberAppear);
                    } else {
                        words.add(text, 1);
                    }
                }
                // Skip to the next word/separator
                i += text.length();
            }
        }

    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> charSet) {
        for (int i = 0; i < str.length(); i++) {
            if (!charSet.contains(str.charAt(i))) {
                charSet.add(str.charAt(i));
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert position >= 0 : "Violation of: position is not >= 0";
        assert position < text
                .length() : "Violation of: position is not < |text|";
        assert separators != null : "Violation of: separators is not null";

        String str = "";
        char returnedChar = 'a';

        if (separators.contains(text.charAt(position))) {
            for (int i = 0; i < text.substring(position, text.length())
                    .length(); i++) {
                returnedChar = text.charAt(position + i);
                if (separators.contains(returnedChar)) {
                    str = str + returnedChar;
                } else {
                    i = text.substring(position, text.length()).length();
                }
            }
        } else {
            for (int i = 0; i < text.substring(position, text.length())
                    .length(); i++) {
                returnedChar = text.charAt(position + i);
                if (!separators.contains(returnedChar)) {
                    str = str + returnedChar;
                } else {
                    i = text.substring(position, text.length()).length();
                }
            }
        }

        return str;
    }

    /**
     * Outputs the opening tags for the output HTML file.
     *
     * @param out
     *            output stream
     * @param file
     *            input file given by user
     * @param x
     *            number of words given by user
     * @updates {@code out}
     * @requires <pre>
     * {@code file} is open and not null and {@code out} is open
     * </pre>
     * @ensures <pre>
     * {@code out = #out * tags}
     * </pre>
     */
    private static void outputHeader(SimpleWriter out, String file, int x) {
        assert out != null : "Violation of : out is not null";
        assert out.isOpen() : "Violation of : out is not open";
        assert file != null : "Violation of : file is not null";

        /**
         * Print out beginning of HTML file
         */
        out.println("<html>");
        out.println("<head>");

        /**
         * Print out title
         */
        out.println("<title>Top " + x + " words in " + file + "</title>");
        out.println("<link href=\"http://web.cse.ohio-state.edu/software/2231/"
                + "web-sw2/assignments/projects/tag-cloud-generator/data/"
                + "tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        out.println("<link href=\"doc/tagcloud.css\" "
                + "rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");

        /**
         * Print out body
         */
        out.println("<body>");
        out.println("<h2>Top " + x + " Words Counted in " + file + "</h2>");
        out.println("<hr>");
        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");

    }

    /**
     * Prints footer for the output HTML file.
     *
     * @param out
     *            output stream
     * @updates {@code out}
     * @requires <pre>
     * {@code out} is open
     * </pre>
     * @ensures <pre>
     * {@code out = #out * tags}
     * </pre>
     */
    private static void outputFooter(SimpleWriter out) {
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * This sorts the words into two different groups. It starts sorting through
     * a comparator in numerical order and then a second ordering method being
     * alphabetically. It would then print to the output file in HTML format
     * with the appropriate fonts.
     *
     * @param mapCount
     *            This is the map of words and numbers that show up
     * @param out
     *            output file stream
     * @param words
     *            number of words given by user
     */
    private static void sortingAndFonts(Map<String, Integer> mapCount,
            SimpleWriter out, int words) {

        //numerical order
        Comparator<Pair<String, Integer>> nums = new Sort();
        SortingMachine<Map.Pair<String, Integer>> sort;
        sort = new SortingMachine1L<Pair<String, Integer>>(nums);

        while (mapCount.size() > 0) {
            Pair<String, Integer> r = mapCount.removeAny();
            sort.add(r);
        }

        sort.changeToExtractionMode();

        //alphabetical ordering
        Comparator<Pair<String, Integer>> numsTwo = new SortTwo();
        SortingMachine<Pair<String, Integer>> sortTwo;
        sortTwo = new SortingMachine1L<Pair<String, Integer>>(numsTwo);

        int min = 0;
        int max = 0;

        //loop ordering
        for (int i = 0; (i < words) && (1 < sort.size()); i++) {
            Pair<String, Integer> wording = sort.removeFirst();
            int neg = words - 1;
            if (i == 0) {
                max = wording.value();
            } else if (i == neg) {
                min = wording.value();
            }
            sortTwo.add(wording);
        }
        sortTwo.changeToExtractionMode();

        //alphabetical + printing to the output stream
        while (sortTwo.size() > 0) {
            Pair<String, Integer> removed = sortTwo.removeFirst();

            final int eleven = 11;
            final int fortyeight = 48;
            int sizeFont = 0;
            if (removed.value() == min) {
                sizeFont = eleven;
            } else if (removed.value() == max) {
                sizeFont = fortyeight;
            } else {
                sizeFont = eleven
                        + ((removed.value() * (fortyeight - eleven)) / (max));
            }

            String f = "f" + sizeFont;

            out.println("<span style=\"cursor:default\" class=\"" + f
                    + "\" title=\"count: " + removed.value() + "\">"
                    + removed.key() + "</span>");
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Ask for input and output file, along with number of words.
         */
        out.print("Enter an input file: ");
        String fileIn = in.nextLine();
        out.print("Enter an output file: ");
        String fileOut = in.nextLine();
        out.print("Enter number of words: ");
        int words = in.nextInteger();

        Reporter.assertElseFatalError(words > 0,
                "Number of words must be greater than 0");

        /*
         * Create output file and print header of HTML file.
         */
        SimpleWriter output = new SimpleWriter1L(fileOut);
        outputHeader(output, fileIn, words);

        /*
         * Create input file.
         */
        SimpleReader input = new SimpleReader1L(fileIn);

        /*
         * Read file and sort values in Map in both alphabetical and decreasing
         * order.
         */
        Map<String, Integer> tmpMap = new Map1L<String, Integer>();
        readFile(tmpMap, input);
        sortingAndFonts(tmpMap, output, words);

        /*
         * Print footer of HTML file.
         */
        outputFooter(output);

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
        output.close();
        input.close();
    }

}
