import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * The program will count word occurrences in an HTML document based on a given
 * input file. The HTML document will include a table with the words and a
 * count, along with being listed in alphabetical order.
 *
 * @author Chloe Feller
 *
 */
public final class WordCounter {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private WordCounter() {
    }

    /**
     * Reads words from the input file and adds them to a {@code Map}. Words are
     * not alphabetized yet
     *
     * @param words
     *            the {@code Map} of words
     * @param file
     *            file input by user
     *
     * @requires file.isOpen
     * @requires words != null
     * @replaces words
     *
     */
    private static void readFile(Map<String, Integer> words,
            SimpleReader file) {
        assert file.isOpen() : "Violation of: file is open";
        assert words != null : "Violation of: words is not null";

        String separator = " \t,.-;'/\"@#$%&()";
        Set<Character> charSet = new Set1L<Character>();

        generateElements(separator, charSet);

        /*
         * Read through the file until all lines are read, while adding words to
         * the Map
         */
        while (!file.atEOS()) {
            String line = file.nextLine();
            int i = 0;

            while (i < line.length()) {
                String text = nextWordOrSeparator(line, i, charSet);
                if (!charSet.contains(text.charAt(0))) {
                    /*
                     * Sees if words contains the word. If it does not, the word
                     * is added. If it does, the number of times it has appeared
                     * is increased.
                     */
                    if (words.hasKey(text)) {
                        int numberAppear = words.value(text);
                        numberAppear++;
                        words.replaceValue(text, numberAppear);
                    } else {
                        words.add(text, 1);
                    }
                }
                // Skip to the next word/separator
                i += text.length();
            }
        }

    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    public static void generateElements(String str, Set<Character> charSet) {
        for (int i = 0; i < str.length(); i++) {
            if (!charSet.contains(str.charAt(i))) {
                charSet.add(str.charAt(i));
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert position >= 0 : "Violation of: position is not >= 0";
        assert position < text
                .length() : "Violation of: position is not < |text|";
        assert separators != null : "Violation of: separators is not null";

        String str = "";
        char returnedChar = 'a';

        if (separators.contains(text.charAt(position))) {
            for (int i = 0; i < text.substring(position, text.length())
                    .length(); i++) {
                returnedChar = text.charAt(position + i);
                if (separators.contains(returnedChar)) {
                    str = str + returnedChar;
                } else {
                    i = text.substring(position, text.length()).length();
                }
            }
        } else {
            for (int i = 0; i < text.substring(position, text.length())
                    .length(); i++) {
                returnedChar = text.charAt(position + i);
                if (!separators.contains(returnedChar)) {
                    str = str + returnedChar;
                } else {
                    i = text.substring(position, text.length()).length();
                }
            }
        }

        return str;
    }

    /**
     * Separates the words in the given {@code Map} in alphabetical order.
     *
     * @param words
     *            the given {@code Map}
     * @param sorter
     *            a {@code Queue} used to help sort the {@code Map}
     *
     * @requires words != null
     * @requires sorter != null
     * @updates words
     */
    private static void alphabetMap(Map<String, Integer> words,
            Queue<String> sorter) {
        assert words != null : "Violation of : words is not null";
        assert sorter != null : "Violation of : sorter is not null";

        Map<String, Integer> tempMap = new Map1L<String, Integer>();
        Comparator<String> order = new StringLT();
        Queue<String> tempSorter = new Queue1L<String>();

        /*
         * Add the words from the Map to the Queue
         */
        while (words.iterator().hasNext()) {
            Pair<String, Integer> newPair = words.removeAny();
            tempMap.add(newPair.key(), newPair.value());
            sorter.enqueue(newPair.key());
        }

        /*
         * Sort the Queue
         */
        sorter.sort(order);

        /*
         * Add the words in alphabetical order back to the Map
         */
        while (sorter.iterator().hasNext()) {
            String text = sorter.dequeue();
            Pair<String, Integer> sortedPair = tempMap.remove(text);
            words.add(sortedPair.key(), sortedPair.value());
            tempSorter.enqueue(text);
        }

        sorter.transferFrom(tempSorter);
    }

    /**
     *
     * Compares two {@code Strings} and returns whether they are in alphabetical
     * order or not.
     *
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String one, String two) {
            return one.toLowerCase().compareTo(two.toLowerCase());
        }
    }

    /**
     * Outputs the alphabetized words into an HTML document, which includes a
     * table with the words and how many times they appear.
     *
     * @param out
     *            the output file
     * @param file
     *            the input file the user gave
     * @param words
     *            the {@code Map} containing the words and how many times they
     *            appear
     * @param sorter
     *            the {@code Queue} containing the words
     *
     * @requires out and file are open
     * @requires words and sorter != null
     */
    private static void outputFile(SimpleWriter out, SimpleReader file,
            Map<String, Integer> words, Queue<String> sorter) {
        assert out.isOpen() : "Violation of : out is open";
        assert file.isOpen() : "Violation of : file is open";
        assert words != null : "Violation of : words is not null";
        assert sorter != null : "Violation of : sorter is not null";

        /*
         * Print out beginning of HTML file
         */
        out.println("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>");
        out.println("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'"
                + " 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>");
        out.println("<html xmlns='http://www.w3.org/1999/xhtml'>");

        /*
         * Print out title
         */
        out.println("<head>");
        out.println("<title>" + file.name() + "</title>");

        /*
         * Print out body
         */
        out.println("<body>");
        out.println("<h1>Words Counted in " + file.name() + "</h2>");

        /*
         * Print out table
         */
        out.println("<table border=\"1\">");
        out.println("<tr>");
        out.println("<th>Words</th>");
        out.println("<th>Counter</th>");
        out.println("</tr>");

        while (words.iterator().hasNext()) {
            Pair<String, Integer> word = words.remove(sorter.dequeue());
            out.println("<tr>");
            out.println("<td>" + word.key() + "</td>");
            out.println("<td>" + word.value() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body>");
        out.println("</head>");
        out.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Ask user for an input and output file
         */
        out.print("Please give an input file: ");
        String input = in.nextLine();
        SimpleReader file = new SimpleReader1L(input);

        out.print("Please give an output file: ");
        String output = in.nextLine();
        SimpleWriter write = new SimpleWriter1L(output);

        /*
         * Puts words in the input file to Strings / Queues (look into to see
         * which is better)
         */
        Map<String, Integer> words = new Map1L<String, Integer>();
        readFile(words, file);

        /*
         * Separate words based on alphabetical order
         */
        Queue<String> sorter = new Queue1L<String>();
        alphabetMap(words, sorter);

        /*
         * Make a method for the output file's code, including a table and the
         * words in alphabetical order
         */
        outputFile(write, file, words, sorter);

        /*
         * Close input and output streams
         */
        file.close();
        write.close();
        in.close();
        out.close();
    }

}
